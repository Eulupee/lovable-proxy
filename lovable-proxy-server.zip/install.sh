#!/bin/bash
echo "================================"
echo "Instalando dependências..."
echo "================================"
npm install

if [ $? -eq 0 ]; then
    echo ""
    echo "================================"
    echo "Instalação concluída!"
    echo "================================"
    echo ""
    echo "Para iniciar o servidor, execute: ./start.sh"
else
    echo "ERRO: Falha ao instalar dependências"
    exit 1
fi
