# Lovable Proxy Server

Servidor proxy para interceptar e rotear requisições ao Lovable sem consumir créditos diretamente.

## 📦 Instalação

1. Faça upload de todos os arquivos para seu servidor via FTP
2. Conecte via SSH ao seu servidor
3. Navegue até a pasta do projeto
4. Instale as dependências: `npm install`

## 🚀 Iniciar o servidor

### Modo produção:
```bash
npm start
```

### Manter rodando em background (com PM2):
```bash
npm install -g pm2
pm2 start server.js --name lovable-proxy
pm2 save
pm2 startup
```

## 📡 Endpoints disponíveis

- Health Check: GET /health
- Proxy Lovable: POST /api/lovable-proxy
- Autorização: POST /api/radioai-authorization
