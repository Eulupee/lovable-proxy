#!/bin/bash
echo "================================"
echo "Iniciando servidor proxy..."
echo "================================"
npm start
