# ⚠️ LEIA ESTE ARQUIVO PRIMEIRO - Instalação SEM SSH

## 📦 Requisitos obrigatórios

Seu servidor PRECISA ter Node.js instalado. Hospedagens que NÃO funcionam:
- ❌ Hospedagem compartilhada tradicional (apenas PHP/cPanel)
- ❌ Hospedagem de arquivos estáticos

## ✅ Alternativas GRATUITAS recomendadas

### 1. Railway.app (MAIS FÁCIL - Recomendado)
1. Acesse https://railway.app
2. Crie conta gratuita
3. Clique em "New Project"
4. Selecione "Deploy from GitHub"
5. Faça upload destes arquivos em um repositório GitHub
6. Railway faz deploy automático
7. Você receberá uma URL tipo: https://seu-app.railway.app

### 2. Render.com
1. Acesse https://render.com
2. Crie conta gratuita
3. New > Web Service
4. Conecte GitHub ou upload manual
5. Deploy automático

### 3. Vercel (apenas se seu servidor for compatível)
```bash
npm install -g vercel
vercel
```

## 🔧 Se você TEM Node.js no servidor FTP

1. Faça upload de todos os arquivos
2. Use o painel de controle da hospedagem para:
   - Executar: `npm install`
   - Executar: `npm start`

## 📝 Testando

Acesse: http://SEU_SERVIDOR:4000/health

Se retornar `{"status":"ok"}` está funcionando!
